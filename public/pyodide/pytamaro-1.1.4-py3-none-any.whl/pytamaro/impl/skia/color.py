from skia import Color4f

from pytamaro.color import Color


def skia_color(color: Color) -> Color4f:
    return Color4f(color.red / 255,
                   color.green / 255,
                   color.blue / 255,
                   color.alpha)
