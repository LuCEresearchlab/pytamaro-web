"""
Pytamaro Graphics compiler.
"""
import sys
import time
from dataclasses import dataclass
from typing import Self, Callable, Any

from pytamaro.graphic import Graphic


@dataclass
class Cons[T]:
    car: T
    cdr: Self | None


def print_cons[T](cons: Cons[T]):
    result = ''
    itr = cons
    while itr is not None:
        result += '\n' + str(itr.car)
        itr = itr.cdr
    return result


def of[T](*args: T, tail: Cons[T] | None = None) -> Cons[T] | None:
    result = tail
    idx = len(args) - 1
    while idx >= 0:
        result = Cons(args[idx], result)
        idx -= 1
    return result


def to_spec(graphic: Graphic):
    before = time.perf_counter_ns()
    to_process_stack: Cons[Graphic] = Cons(graphic, None)
    specs_stack: Cons[tuple[int, Callable | dict[str, Any]]] | None = None

    while to_process_stack is not None:
        curr = to_process_stack.car
        to_process_stack = to_process_stack.cdr
        deps, frame = curr.deps_and_spec()
        to_process_stack = of(*deps, tail=to_process_stack)
        specs_stack = Cons(
            (len(deps), frame) if callable(frame) else (0, frame),
            specs_stack
        )

    assert specs_stack is not None

    work_stack: Cons[dict[str, Any]] | None = None

    def pop_instruction() -> tuple[int, Callable | dict[str, Any]]:
        nonlocal specs_stack
        car = specs_stack.car
        specs_stack = specs_stack.cdr
        return car

    def pop_stack() -> dict[str, Any]:
        nonlocal work_stack
        car = work_stack.car
        work_stack = work_stack.cdr
        return car

    while specs_stack is not None:
        to_pop, it = pop_instruction()
        match to_pop:
            case 0:
                work_stack = Cons(it, work_stack)
            case 1:
                arg0 = pop_stack()
                work_stack = Cons(it(arg0), work_stack)
            case 2:
                arg0 = pop_stack()
                arg1 = pop_stack()
                work_stack = Cons(it(arg0, arg1), work_stack)
            case _:
                raise ValueError(f'Instruction takes {to_pop} arguments!')

    assert work_stack is not None and work_stack.cdr is None
    result = work_stack.car

    assert result is not None

    print(f'Compiled spec size: {sys.getsizeof(result)}', end=' ')
    print(f'in {(time.perf_counter_ns() - before) / 1e9} seconds')

    return result
