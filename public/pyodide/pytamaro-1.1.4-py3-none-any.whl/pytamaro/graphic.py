"""
Type `Graphic`, that includes a graphic with a pinning position.
"""

from abc import ABC
from dataclasses import dataclass, field, asdict
from typing import Any, Callable, Self

from pytamaro.color import Color
from pytamaro.localization import translate
from pytamaro.point import Point
from pytamaro.point_names import center, center_left, center_right, bottom_center, top_center


@dataclass(frozen=True, eq=False)
class Graphic(ABC):
    """
    A graphic (image) with a position for pinning.

    The pinning position is used in the following operations:

    - rotation (to determine the center of rotation)
    - graphic composition (two graphics get composed aligning their pinning
      position).
    """

    type: str = field(init=False)

    def __post_init__(self):
        object.__setattr__(self, "type", self.__class__.__name__)

    def deps_and_spec(self) -> tuple[list[Self], Callable | dict[str, Any]]:
        """
        Create specs to render this graphic
        """
        return (
            [],
            asdict(self),
        )


@dataclass(frozen=True, eq=False)
class Empty(Graphic):
    """
    An empty graphic.
    """

    def __repr__(self) -> str:
        return f"{translate('empty_graphic')}()"


@dataclass(frozen=True, eq=False)
class Rectangle(Graphic):
    """
    A rectangle.
    """
    width: float
    height: float
    color: Color

    def __repr__(self) -> str:
        return f"{translate('rectangle')}({self.width}, {self.height}, {self.color})"


@dataclass(frozen=True, eq=False)
class Ellipse(Graphic):
    """
    An ellipse.
    """
    width: float
    height: float
    color: Color

    def __repr__(self) -> str:
        return f"{translate('ellipse')}({self.width}, {self.height}, {self.color})"


@dataclass(frozen=True, eq=False)
class CircularSector(Graphic):
    """
    A circular sector (with an angle between 0 and 360).
    Its pinning position is the center of the circle from which it is taken.
    """
    radius: float
    angle: float
    color: Color

    def __repr__(self) -> str:
        return f"{translate('circular_sector')}({self.radius}, {self.angle}, {self.color})"


@dataclass(frozen=True, eq=False)
class Triangle(Graphic):
    """
    A triangle specified using two sides and the angle between them.
    The first side extends horizontally to the right.
    The second side is rotated counterclockwise by the specified angle.

    Its pinning position is the centroid of the triangle.
    """
    side1: float
    side2: float
    angle: float
    color: Color

    def __repr__(self) -> str:
        return f"{translate('triangle')}({self.side1}, {self.side2}, {self.angle}, {self.color})"


@dataclass(frozen=True, eq=False)
class Text(Graphic):
    """
    Graphic containing text, using a given font with a given typographic size.
    Its pinning position is horizontally aligned on the left and vertically on
    the baseline of the text.
    """
    text: str
    font_name: str
    text_size: float
    color: Color

    def __repr__(self) -> str:
        return f"{translate('text')}({self.text!r}, {self.font_name!r}, {self.text_size}, {self.color})"  # pylint: disable=line-too-long


@dataclass(frozen=True, eq=False)
class Compose(Graphic):
    """
    Represents the composition of two graphics, one in the foreground and the
    other in the background, joined on their pinning positions.
    """
    foreground: Graphic
    background: Graphic

    def __repr__(self) -> str:
        return f"{translate('compose')}({self.foreground}, {self.background})"

    def deps_and_spec(self) -> tuple[list[Self], Callable | dict[str, Any]]:
        def add_flat_child(result: dict[str, Any],
                           child: dict[str, Any],
                           key: str):
            """
            Inline pinning position of children of type Pin to flatten the tree.
            """
            if child['type'] == Pin.__name__:
                result[f'{key}_pin'] = child['pinning_point']
                # Also flatten nested pins
                while child['type'] == Pin.__name__:
                    child = child['graphic']
            result[key] = child

        def build_spec(foreground: dict[str, Any],
                       background: dict[str, Any]) -> dict[str, Any]:
            result = {'type': self.type}
            add_flat_child(result, foreground, 'foreground')
            add_flat_child(result, background, 'background')
            return result

        return (
            [self.foreground, self.background],
            build_spec
        )


@dataclass(frozen=True, eq=False)
class Pin(Graphic):
    """
    Represents the pinning of a graphic in a certain position on its bounds.
    """
    graphic: Graphic
    pinning_point: Point

    def __repr__(self) -> str:
        return f"{translate('pin')}({self.pinning_point}, {self.graphic})"

    def deps_and_spec(self) -> tuple[list[Self], Callable | dict[str, Any]]:
        # Flatten pin(pin(...))
        child_graphic = self.graphic
        while isinstance(child_graphic, Pin):
            child_graphic = child_graphic.graphic
        return (
            [child_graphic],
            lambda graphic: {
                'graphic': graphic,
                'pinning_point': asdict(self.pinning_point),
                'type': self.type,
            }
        )


@dataclass(frozen=True, eq=False)
class Rotate(Graphic):
    """
    Represents the counterclockwise rotation of a graphic
    by a certain angle around the pinning position.
    The angle is expressed in degrees.
    """
    graphic: Graphic
    angle: float

    def __repr__(self) -> str:
        return f"{translate('rotate')}({self.angle}, {self.graphic})"

    def deps_and_spec(self) -> tuple[list[Self], Callable | dict[str, Any]]:
        return (
            [self.graphic],
            lambda graphic: {
                'graphic': graphic,
                'angle': self.angle,
                'type': self.type,
            }
        )


@dataclass(frozen=True, eq=False)
class Beside(Graphic):
    """
    Represents the composition of two graphics one beside the other,
    vertically centered.
    """
    left_graphic: Graphic
    right_graphic: Graphic

    def __repr__(self) -> str:
        return f"{translate('beside')}({self.left_graphic}, {self.right_graphic})"

    def deps_and_spec(self) -> tuple[list[Self], Callable | dict[str, Any]]:
        return (
            [self.left_graphic, self.right_graphic],
            lambda left_graphic, right_graphic: {
                'graphic': {
                    'foreground': left_graphic,
                    'foreground_pin': asdict(center_right),
                    'background': right_graphic,
                    'background_pin': asdict(center_left),
                    'type': Compose.__name__,
                },
                'pinning_point': asdict(center),
                'type': Pin.__name__,
            }
        )


@dataclass(frozen=True, eq=False)
class Above(Graphic):
    """
    Represents the composition of two graphics one above the other,
    horizontally centered.
    """
    top_graphic: Graphic
    bottom_graphic: Graphic

    def __repr__(self) -> str:
        return f"{translate('above')}({self.top_graphic}, {self.bottom_graphic})"

    def deps_and_spec(self) -> tuple[list[Self], Callable | dict[str, Any]]:
        return (
            [self.top_graphic, self.bottom_graphic],
            lambda top_graphic, bottom_graphic: {
                'graphic': {
                    'foreground': top_graphic,
                    'foreground_pin': asdict(bottom_center),
                    'background': bottom_graphic,
                    'background_pin': asdict(top_center),
                    'type': Compose.__name__,
                },
                'pinning_point': asdict(center),
                'type': Pin.__name__,
            }
        )


@dataclass(frozen=True, eq=False)
class Overlay(Graphic):
    """
    Represents the composition of two graphics that one overlay other,
    the center of the two graphics are at the same position
    """
    front_graphic: Graphic
    back_graphic: Graphic

    def __repr__(self) -> str:
        return f"{translate('overlay')}({self.front_graphic}, {self.back_graphic})"

    def deps_and_spec(self) -> tuple[list[Self], Callable | dict[str, Any]]:
        return (
            [self.front_graphic, self.back_graphic],
            lambda front_graphic, back_graphic: {
                'foreground': front_graphic,
                'foreground_pin': asdict(center),
                'background': back_graphic,
                'background_pin': asdict(center),
                'type': Compose.__name__,
            },
        )
