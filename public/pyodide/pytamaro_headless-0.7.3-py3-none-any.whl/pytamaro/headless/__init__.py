"""
Headless implementation of pytamaro.

Graphics are purely data structures and have no notion of rendering.
In order to render them, a "pytamaro_renderer" python module must be
supplied.
"""
import sys

setattr(sys.modules["pytamaro"], "RENDERER", "none")
