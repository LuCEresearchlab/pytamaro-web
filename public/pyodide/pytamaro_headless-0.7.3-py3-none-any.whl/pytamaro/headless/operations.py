# pylint: disable=C0114
# pylint: disable=C0116
# pylint: disable=R0801
from pytamaro.core.checks import check_angle, check_point
from pytamaro.core.point import Point
from pytamaro.core.utils import export
from pytamaro.headless.checks import check_graphic
from pytamaro.headless.graphic import Graphic, Compose, Pin, Overlay, Beside, Above, Rotate

try:
    from pytamaro_renderer import rendered_width, rendered_height  # type: ignore
except ImportError as e:
    raise EnvironmentError("Forgot to provide a 'pytamaro_renderer' module?") from e


@export
def graphic_width(graphic: Graphic) -> int:
    check_graphic(graphic)
    return rendered_width(graphic)


@export
def graphic_height(graphic: Graphic) -> int:
    check_graphic(graphic)
    return rendered_height(graphic)


@export
def compose(foreground_graphic: Graphic, background_graphic: Graphic) -> Graphic:
    check_graphic(foreground_graphic, "foreground_graphic")
    check_graphic(background_graphic, "background_graphic")
    return Compose(foreground_graphic, background_graphic)


@export
def pin(point: Point, graphic: Graphic) -> Graphic:
    check_point(point)
    check_graphic(graphic)
    return Pin(graphic, point)


@export
def overlay(foreground_graphic: Graphic, background_graphic: Graphic) -> Graphic:
    check_graphic(foreground_graphic, "foreground_graphic")
    check_graphic(background_graphic, "background_graphic")
    return Overlay(foreground_graphic, background_graphic)


@export
def beside(left_graphic: Graphic, right_graphic: Graphic) -> Graphic:
    check_graphic(left_graphic, "left_graphic")
    check_graphic(right_graphic, "right_graphic")
    return Beside(left_graphic, right_graphic)


@export
def above(top_graphic: Graphic, bottom_graphic: Graphic) -> Graphic:
    check_graphic(top_graphic, "top_graphic")
    check_graphic(bottom_graphic, "bottom_graphic")
    return Above(top_graphic, bottom_graphic)


@export
def rotate(angle: float, graphic: Graphic) -> Graphic:
    check_angle(angle)
    check_graphic(graphic)
    return Rotate(graphic, angle)
