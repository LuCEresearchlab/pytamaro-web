# pylint: disable=C0114
# pylint: disable=C0115
# pylint: disable=C0116
from typing import TypeVar, Callable

from pytamaro.core.utils import export
from pytamaro.headless.graphic import Graphic
from pytamaro.headless.primitives import empty_graphic

try:
    from pytamaro_renderer import run_interact  # type: ignore
except ImportError as e:
    raise EnvironmentError("Forgot to provide a 'pytamaro_renderer' module?") from e

M = TypeVar('M')


# pylint: disable=R0913
@export
def interact(initial_model: M,
             *,
             interval: int = 200,
             on_tick: Callable[[M], M] = lambda model: model,
             on_render: Callable[[M], Graphic] = lambda model: empty_graphic(),
             on_key_up: Callable[[M, str], M] = lambda model, key: model,
             on_key_down: Callable[[M, str], M] = lambda model, key: model,
             on_key_press: Callable[[M, str], M] = lambda model, key: model,
             on_mouse_up: Callable[[M, int], M] = lambda model, button: model,
             on_mouse_down: Callable[[M, int], M] = lambda model, button: model,
             on_mouse_move: Callable[[M, int, int], M] = lambda model, x, y: model):
    run_interact({
        "initial_model": initial_model,
        "interval": interval,
        "on_tick": on_tick,
        "on_render": lambda m: on_render(m).as_dict(),
        "on_key_down": on_key_down,
        "on_key_up": on_key_up,
        "on_key_press": on_key_press,
        "on_mouse_down": on_mouse_down,
        "on_mouse_up": on_mouse_up,
        "on_mouse_move": on_mouse_move,
    })
