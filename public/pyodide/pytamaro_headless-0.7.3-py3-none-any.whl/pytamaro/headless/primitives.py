# pylint: disable=C0114
# pylint: disable=C0116
# pylint: disable=R0801
from pytamaro.core.checks import (check_angle, check_color, check_length,
                                  check_number)
from pytamaro.core.color import Color
from pytamaro.core.utils import export
from pytamaro.headless.checks import check_type
from pytamaro.headless.graphic import (CircularSector, Ellipse, Empty, Graphic,
                                       Rectangle, Text, Triangle)


@export
def rectangle(width: float, height: float, color: Color) -> Graphic:
    check_length(width, "width")
    check_length(height, "height")
    check_color(color)
    return Rectangle(width, height, color)


@export
def empty_graphic() -> Graphic:
    return Empty()


@export
def ellipse(width: float, height: float, color: Color) -> Graphic:
    check_length(width, "width")
    check_length(height, "height")
    check_color(color)
    return Ellipse(width, height, color)


@export
def circular_sector(radius: float, angle: float, color: Color) -> Graphic:
    check_length(radius, "radius")
    check_angle(angle, 0, 360)
    check_color(color)
    return CircularSector(radius, angle, color)


@export
def triangle(side1: float, side2: float, angle: float, color: Color) -> Graphic:
    check_length(side1, "side1")
    check_length(side2, "side2")
    check_angle(angle, 0, 180)
    return Triangle(side1, side2, angle, color)


@export
def text(content: str, font: str, points: float, color: Color) -> Graphic:
    check_type(content, str, "content")
    check_type(font, str, "font")
    check_number(points, "points")
    check_color(color)
    return Text(content, font, points, color)
