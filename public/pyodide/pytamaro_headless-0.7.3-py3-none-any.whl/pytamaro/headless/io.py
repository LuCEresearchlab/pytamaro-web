# pylint: disable=C0114
# pylint: disable=C0116
# pylint: disable=R0801
import asyncio
import sys
from typing import List

from pytamaro.core.localization import translate
from pytamaro.core.checks import check_type
from pytamaro.core.utils import export
from pytamaro.headless.checks import check_graphic
from pytamaro.headless.graphic import Graphic

try:
    from pytamaro_renderer import render_image, render_animation  # type: ignore
except ImportError as e:
    raise EnvironmentError("Forgot to provide a 'pytamaro_renderer' module?") from e


@export
def show_graphic(graphic: Graphic, debug: bool = False):
    check_graphic(graphic)
    check_type(debug, bool, "debug")
    b64_str = asyncio.run(render_image(graphic.as_dict(), debug))
    prefix = "@@@PYTAMARO_DATA_URI_BEGIN@@@"
    suffix = "@@@PYTAMARO_DATA_URI_END@@@"
    print(f"{prefix}{b64_str}{suffix}", end="")
    sys.stdout.flush()



# noinspection PyUnusedLocal
@export
def save_graphic(filename: str, graphic: Graphic, debug: bool = False):
    raise NotImplementedError("Not available in pytamaro-headless")


# noinspection PyUnusedLocal
@export
def save_animation(filename: str, graphics: List[Graphic], duration: int = 40, loop: bool = True):
    raise NotImplementedError("Not available in pytamaro-headless")


# noinspection PyUnusedLocal
@export
def show_animation(graphics: List[Graphic], duration: int = 40, loop: bool = True):
    check_type(graphics, list, "graphics")
    if len(graphics) == 0:
        raise ValueError(translate("EMPTY_GRAPHICS_LIST"))
    for idx, graphic in enumerate(graphics):
        check_type(graphic, Graphic, "graphics", idx)
    check_type(duration, int, "duration")
    check_type(loop, bool, "loop")

    frames = list(map(lambda g: g.as_dict(), graphics))
    render_animation(frames, duration, loop)
