# pylint: disable=C0114
# pylint: disable=C0116
from typing import Any

from pytamaro.core.checks import check_type
from pytamaro.headless.graphic import Graphic


def check_graphic(graphic: Any, parameter_name: str = "graphic"):
    check_type(graphic, Graphic, parameter_name, simplified_type=Graphic)
