# pylint: disable=C0114
# pylint: disable=C0115
# pylint: disable=C0116
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

from pytamaro.core.color import Color
from pytamaro.core.localization import translate
from pytamaro.core.point import Point
from pytamaro.core.point_names import center_left, center, center_right, top_center, bottom_center


@dataclass(frozen=True, eq=True)
class Graphic(ABC):

    @abstractmethod
    def as_dict(self) -> dict[str, Any]:
        pass


@dataclass(frozen=True, eq=True)
class Empty(Graphic):

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "empty",
        }

    def __repr__(self) -> str:
        return f"{translate('empty_graphic')}()"


@dataclass(frozen=True, eq=True)
class Rectangle(Graphic):
    width: float
    height: float
    color: Color

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "rectangle",
            "width": self.width,
            "height": self.height,
            "color": self.color.as_dict(),
        }

    def __repr__(self) -> str:
        return f"{translate('rectangle')}({self.width}, {self.height}, {self.color})"


@dataclass(frozen=True, eq=True)
class Ellipse(Graphic):
    width: float
    height: float
    color: Color

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "ellipse",
            "width": self.width,
            "height": self.height,
            "color": self.color.as_dict(),
        }

    def __repr__(self) -> str:
        return f"{translate('ellipse')}({self.width}, {self.height}, {self.color})"


@dataclass(frozen=True, eq=True)
class CircularSector(Graphic):
    radius: float
    angle: float
    color: Color

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "circular_sector",
            "radius": self.radius,
            "angle": self.angle,
            "color": self.color.as_dict(),
        }

    def __repr__(self) -> str:
        return f"{translate('circular_sector')}({self.radius}, {self.angle}, {self.color})"


@dataclass(frozen=True, eq=True)
class Triangle(Graphic):
    side1: float
    side2: float
    angle: float
    color: Color

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "triangle",
            "side1": self.side1,
            "side2": self.side2,
            "angle": self.angle,
            "color": self.color.as_dict(),
        }

    def __repr__(self) -> str:
        return f"{translate('triangle')}({self.side1}, {self.side2}, {self.angle}, {self.color})"


@dataclass(frozen=True, eq=True)
class Text(Graphic):
    text: str
    font_name: str
    text_size: float
    color: Color

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "text",
            "text": self.text,
            "font_name": self.font_name,
            "text_size": self.text_size,
            "color": self.color.as_dict(),
        }

    def __repr__(self) -> str:
        return f"{translate('text')}({self.text!r}, {self.font_name!r}, {self.text_size}, {self.color})"  # pylint: disable=line-too-long


@dataclass(frozen=True, eq=True)
class Compose(Graphic):
    foreground: Graphic
    background: Graphic

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "compose",
            "foreground": self.foreground.as_dict(),
            "background": self.background.as_dict(),
        }

    def __repr__(self) -> str:
        return f"{translate('compose')}({self.foreground}, {self.background})"


@dataclass(frozen=True, eq=True)
class Pin(Graphic):
    graphic: Graphic
    pinning_point: Point

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "pin",
            "graphic": self.graphic.as_dict(),
            "pinning_point": self.pinning_point.as_dict(),
        }

    def __repr__(self) -> str:
        return f"{translate('pin')}({self.pinning_point}, {self.graphic})"


@dataclass(frozen=True, eq=True)
class Rotate(Graphic):
    graphic: Graphic
    angle: float

    def as_dict(self) -> dict[str, Any]:
        return {
            "type": "rotate",
            "graphic": self.graphic.as_dict(),
            "angle": self.angle,
        }

    def __repr__(self) -> str:
        return f"{translate('rotate')}({self.angle}, {self.graphic})"


@dataclass(frozen=True, eq=True)
class Beside(Graphic):
    left_graphic: Graphic
    right_graphic: Graphic

    def as_dict(self) -> dict[str, Any]:
        return Pin(Compose(Pin(self.left_graphic, center_right),
                           Pin(self.right_graphic, center_left)),
                   center).as_dict()

    def __repr__(self) -> str:
        return f"{translate('beside')}({self.left_graphic}, {self.right_graphic})"


@dataclass(frozen=True, eq=True)
class Above(Graphic):
    top_graphic: Graphic
    bottom_graphic: Graphic

    def as_dict(self) -> dict[str, Any]:
        return Pin(Compose(Pin(self.top_graphic, bottom_center),
                           Pin(self.bottom_graphic, top_center)),
                   center).as_dict()

    def __repr__(self) -> str:
        return f"{translate('above')}({self.top_graphic}, {self.bottom_graphic})"


@dataclass(frozen=True, eq=True)
class Overlay(Graphic):
    front_graphic: Graphic
    back_graphic: Graphic

    def as_dict(self) -> dict[str, Any]:
        return Pin(Compose(Pin(self.front_graphic, center),
                           Pin(self.back_graphic, center)),
                   center).as_dict()

    def __repr__(self) -> str:
        return f"{translate('overlay')}({self.front_graphic}, {self.back_graphic})"
